Travel Planner — app-only sharing package

Open START_HERE.html after extracting the whole ZIP, or open:
https://basixmaster.github.io/Travel_Planner_App/travel_planner.html

Windows, Linux and macOS: extract the ZIP and open START_HERE.html in a current
browser. Android and iOS/iPadOS can extract ZIP files too, but file managers may
preview local HTML or restrict scripts/storage. Use the HTTPS app for the reliable
phone experience, GitHub updates and installed offline reopening.

No plans, credentials, tokens, passwords or encrypted access bundles are included.
On each new device/browser, obtain your encrypted access-bundle JSON privately
from the owner. Open the HTTPS app, choose Download / update plans, import that
file once and enter the download password. Keep the bundle and password private.
Download while online before travelling; keep large downloads in the foreground.

On iPhone/iPad, first add/open the Home Screen app if that is how you will use it,
then import and download there. Safari and its installed app may use separate
storage. Downloads/favorites belong to this device/browser/profile; clearing data
or browser eviction can remove them. Live maps/weather require internet.

The unpacked local overview has no plans initially. Local file storage is
browser-dependent and cannot register a service worker; it is not equivalent to
the HTTPS app. The ZIP is portable packaging, not a native installer or an offline
copy of private itineraries. No EXE, Python, Node or local server is required.

Latest app ZIP:
https://github.com/BasixMaster/Travel_Planner_App/raw/refs/heads/main/downloads/Travel_Planner_App.zip
